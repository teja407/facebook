Configuration Main
{

Import-DscResource -ModuleName PSDesiredStateConfiguration

Node "localhost"
{

	# Install the IIS role 
	WindowsFeature IIS 
	{ 
		Ensure          = "Present" 
		Name            = "Web-Server" 
	}    

    # The File resource can ensure the state of files, or copy them from a source to a destination with persistent updates.
    File HelloWorld 
    {
        DestinationPath = "C:\inetpub\wwwroot\index.html"
        Ensure = "Present"
        Contents   = "Hello World!"
    }
  }
}